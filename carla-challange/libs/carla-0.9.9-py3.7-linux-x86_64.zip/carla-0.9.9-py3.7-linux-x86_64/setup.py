from distutils.core import setup
setup(name='carla',
      version='0.9.9', #doesn't matter I guess
      py_modules=['carla'],
      )
